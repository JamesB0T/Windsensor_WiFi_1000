Notes on the diagnostic tool
############################

1.) Install firmware
--------------------

The required firmware firmware_V1.04a.wsb must be installed so that the diagnostic tool can receive the sensor data from the wind sensor. Firmware versions older than V1.04 do not support the diagnostic function.

2.) Set Diagnostic Mode
-----------------------

Next the wind sensor is set to "Diagnostic Mode" via the Settings page. From now on, the diagnostic data is output via a JSON interface. Other functions of the wind sensor are not possible. On the main page only the buttons "Device Settings" and "System Help" can be selected. All other buttons are deactivated as long as the Diagnostic Mode is active. This is necessary to ensure sufficient performance that is not disturbed by other activities. In addition, all other web clients docked to the wind sensor should be disconnected.

3.) Open Diagnostic Tool
------------------------

Then open the HTML file "Diagnostic_Tool.html" on a laptop or PC. The computer used should have an up-to-date, powerful web browser such as FireFox or Crome. The IP of the wind sensor must still be adapted if necessary. With Connect you can connect to the wind sensor. If the connection is successful, a green dot flashes next to the buttons during each JSON telegram transmission. If required, the connection can also be disconnected with Disconnect. The WLAN connection quality of the wind sensor is displayed behind the dot. It should be greater than 50% to ensure stable data transmission. Otherwise the data transmission may be disturbed and prevents or slows down a data update in the diagrams.

4.)  Description of the diagrams
--------------------------------

The following diagrams are displayed:

Oscilloscope:

The Hall sensor data are displayed at the same time as in an oscilloscope. The resolution is 1 ms. The time axis runs from 0...1000 ms. Triggering takes place on the falling edge of the speed sensor. Data is updated as long as the shell wheel rotates. If the shell wheel is stationary, the data transmission stops.

Pulse Counter:

In the Pulse Counter diagram, the number of pulses per revolution of the wind direction sensor is displayed. The data runs from right to left. 100 consecutive values are displayed. The most current values appear on the right and are shifted to the left for new incoming data.

Time1 / Time2:

In this diagram the determined time values for Time1 and Time2 are displayed. Time1 is the rotation time of the shell wheel per revolution. Time2 is the time between the falling edge of the speed sensor and the first falling edge of the wind direction sensor per revolution (see oscilloscope).

Wind Direction:

This diagram shows continuously the calculated wind direction in degrees, which results from Time1 and Time2.

Wind Speed:

This diagram shows continuously the calculated wind speed in m/s, which results from Time1.

5.) Tips for Adjusting the Metal Shield and the Wind Direction Magnet
---------------------------------------------------------------------

First, the magnet (D3x6) for the wind speed should be set so that it switches safely at all times per revolution. If there is no negative impulse in the blue line in the oscillogram, the magnet is installed the wrong way round or is too far away.

The metal shield and the wind direction magnet (D3x3) must then be adjusted to each other in such a way that each revolution produces a negative impulse for the speed sensor and the wind direction sensor respectively. The results can be easily followed in an oscilloscope. This behavior must be given for all wind directions. The condition is often only met in some direction ranges. Then the magnet must be changed in the height of the groove in such a way that the desired behaviour is achieved. If it is not possible to find a reasonable position for the magnet, it can be helpful to install the magnet the other way round and test it again.

An important aid is the pulse counter diagram. There you can continuously check if the wind direction sensor switches 1x per revolution. With a correctly adjusted magnet, the value 1 must always appear for all wind directions. If values greater than 1 appear, the wind direction sensor switches several times per revolution. If a 0 appears, the wind direction sensor does not switch at all.

The effects of the settings can be examined in the Time1/Time2 diagram and in the wind direction diagram. If the settings are correct, the Time2 value must not be greater than the Time1 value. Depending on the wind direction, the Time2 value varies between 0 ms and Time1. If the magnet is set incorrectly and occasionally does not switch per revolution, the Time2 value is significantly greater than Time1. In this case, the wind direction is calculated incorrectly and the wind direction value in the last diagram starts to jump. If the sensor switches several times per revolution, Time2 is calculated incorrectly because it is triggered too early or too late.

Info: All diagram data are continuously updated every 2 seconds. A higher update rate is not possible because the data acquisition takes place over 1 s and the data exchange between wind sensor and diagnostic tool is asynchronous. Only one diagnostic tool may be connected to the wind sensor at the same time. If several diagnostic tools are docked at the same time, the data transmission is disturbed due to overload. Under certain circumstances, the wind sensor cannot be reached for several minutes and does not transmit any data. As a general rule, you should ensure that there is a sufficiently stable WLAN connection (QC > 50%) so that the diagnostic tool can continuously display data. After successful adjustment, the diagnostic mode can be left and normal data transmission can be set.
