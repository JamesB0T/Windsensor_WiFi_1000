// Wind Speed
var server_name = '192.168.4.1';


// Complex wind instrument
windGauge = new steelseries.WindDirection2('myCanvas', {
    size: 340,
    section: [steelseries.Section(-60, -20, 'rgba(255, 0, 0, 0.8)'), steelseries.Section(20, 60, 'rgba(0, 255, 0, 0.8)'), steelseries.Section(130, -130, 'rgba(255, 255, 0, 0.5)')],
    frameDesign: steelseries.FrameDesign.BLACK_METAL,
    backgroundColor: steelseries.BackgroundColor.ANTHRACITE,
	pointSymbolsVisible: true,
    lcdVisible: true,
    lcdColor: steelseries.LcdColor.STANDARD,
    lcdTitleStrings: ['Direction [°]', 'Speed [m/s]'],
    pointerColor: steelseries.ColorDef.RED,
    pointerTypeLatest: steelseries.PointerType.TYPE6,
    pointerTypeAverage: steelseries.PointerType.TYPE6,
    degreeScaleHalf: true,
});
windGauge.setValueAnimatedAverage(0);
windGauge.setValueAnimatedLatest(0);


// Initialization for line diagram speed
linegraph1 = new RGraph.SVG.Line({
	id: 'chart-container1',
	data: RGraph.SVG.arrayFill({
		array:  [],
		value:  0,
		length: 1000
	}),
	options: {
		// Margins and border
		hmargin: 0,
		marginLeft: 50,
		marginBottom: 50,
		backgroundGridBorder: false,
		// Titles
		title: 'Hall Speed [bin] (blue),Hall Direction [bin] (red), Time [ms]',
		titleX: 'Time [min]',
		// Y axis parameter
		yaxis: true,
		yaxisScaleMax: 4,
		yaxisScaleMin: 0,
		yaxisLabelsCount: 4,
		backgroundGridHlinesCount: 8,
		// X axis parameter
		xaxisLabelsPosition: 'edge',
		xaxisTickmarks: false,		
		backgroundGridVlines: true,
		backgroundGridVlinesCount: 21,
		xaxisLabels: ['0','100','200','300','400','500','600','700','800','900','1000'],
		// Colors and lines
		colors: ['#3366CB'],
		textColor: '#808080',
		xaxisColor: '#808080',
		yaxisColor: '#808080',
		backgroundGridColor: '#808080',
		linewidth: 2,
		filled: false,
		filledColors: ['rgba(0,0,255,0.5)']
	}
}).draw();

// Initialization for line diagram direction
linegraph2 = new RGraph.SVG.Line({
	id: 'chart-container1',
	data: RGraph.SVG.arrayFill({
		array:  [],
		value:  0,
		length: 1000
	}),
	options: {
		// Margins and border
		hmargin: 0,
		marginLeft: 50,
		marginBottom: 50,
		backgroundGridBorder: false,
		// Titles

		// Y axis parameter
		yaxis: true,
		yaxisScaleMax: 4,
		yaxisScaleMin: 0,
		yaxisLabelsCount: 4,
		backgroundGridHlinesCount: 8,
		// X axis parameter
		xaxisLabelsPosition: 'edge',
		xaxisTickmarks: false,		
		backgroundGridVlines: true,
		backgroundGridVlinesCount: 21,
		xaxisLabels: ['0','100','200','300','400','500','600','700','800','900','1000'],
		// Colors and lines
		colors: ['#FF0000'],
		textColor: '#808080',
		xaxisColor: '#808080',
		yaxisColor: '#808080',
		backgroundGridColor: '#808080',
		linewidth: 2,
		filled: false,
		filledColors: ['rgba(0,0,255,0.5)']
	}
}).draw();

// Initialization for line diagram puls counter
linegraph3 = new RGraph.SVG.Line({
	id: 'chart-container2',
	data: RGraph.SVG.arrayFill({
		array:  [],
		value:  0,
		length: 100
	}),
	options: {
		// Margins and border
		hmargin: 0,
		marginLeft: 50,
		marginBottom: 50,
		backgroundGridBorder: false,
		// Titles
		title: 'Puls Counter Wind Direction [1] (per revolution), Time Historie [1]',
		titleX: 'Time [min]',
		// Y axis parameter
		yaxis: true,
		yaxisScaleMax: 4,
		yaxisScaleMin: 0,
		yaxisLabelsCount: 4,
		backgroundGridHlinesCount: 8,
		// X axis parameter
		xaxisLabelsPosition: 'edge',
		xaxisTickmarks: false,		
		backgroundGridVlines: true,
		backgroundGridVlinesCount: 21,
		xaxisLabels: ['100','90','80','70','60','50','40','30','20','10','0'],
		// Colors and lines
		colors: ['#00FFFF'],
		textColor: '#808080',
		xaxisColor: '#808080',
		yaxisColor: '#808080',
		backgroundGridColor: '#808080',
		linewidth: 2,
		filled: false,
		filledColors: ['rgba(0,0,255,0.5)']
	}
}).draw();

// Initialization for line diagram time1
linegraph4 = new RGraph.SVG.Line({
	id: 'chart-container3',
	data: RGraph.SVG.arrayFill({
		array:  [],
		value:  0,
		length: 100
	}),
	options: {
		// Margins and border
		hmargin: 0,
		marginLeft: 50,
		marginBottom: 50,
		backgroundGridBorder: false,
		// Titles
		title: 'Time1 [ms] (blue) and Time2 [ms] (red), Time Historie [1]',
		titleX: 'Time [min]',
		// Y axis parameter
		yaxis: true,
		yaxisScaleMax: 1000,
		yaxisScaleMin: 0,
		yaxisLabelsCount: 4,
		backgroundGridHlinesCount: 8,
		// X axis parameter
		xaxisLabelsPosition: 'edge',
		xaxisTickmarks: false,		
		backgroundGridVlines: true,
		backgroundGridVlinesCount: 21,
		xaxisLabels: ['100','90','80','70','60','50','40','30','20','10','0'],
		// Colors and lines
		colors: ['#3366CB'],
		textColor: '#808080',
		xaxisColor: '#808080',
		yaxisColor: '#808080',
		backgroundGridColor: '#808080',
		linewidth: 2,
		filled: false,
		filledColors: ['rgba(0,0,255,0.5)']
	}
}).draw();

// Initialization for line diagram time2
linegraph5 = new RGraph.SVG.Line({
	id: 'chart-container3',
	data: RGraph.SVG.arrayFill({
		array:  [],
		value:  0,
		length: 100
	}),
	options: {
		// Margins and border
		hmargin: 0,
		marginLeft: 50,
		marginBottom: 50,
		backgroundGridBorder: false,
		// Titles

		// Y axis parameter
		yaxis: true,
		yaxisScaleMax: 1000,
		yaxisScaleMin: 0,
		yaxisLabelsCount: 4,
		backgroundGridHlinesCount: 8,
		// X axis parameter
		xaxisLabelsPosition: 'edge',
		xaxisTickmarks: false,		
		backgroundGridVlines: true,
		backgroundGridVlinesCount: 21,
		xaxisLabels: ['100','90','80','70','60','50','40','30','20','10','0'],
		// Colors and lines
		colors: ['#FF0000'],
		textColor: '#808080',
		xaxisColor: '#808080',
		yaxisColor: '#808080',
		backgroundGridColor: '#808080',
		linewidth: 2,
		filled: false,
		filledColors: ['rgba(0,0,255,0.5)']
	}
}).draw();

// Initialization for line diagram wind direction
linegraph6 = new RGraph.SVG.Line({
	id: 'chart-container4',
	data: RGraph.SVG.arrayFill({
		array:  [],
		value:  0,
		length: 100
	}),
	options: {
		// Margins and border
		hmargin: 0,
		marginLeft: 50,
		marginBottom: 50,
		backgroundGridBorder: false,
		// Titles
		title: 'Wind Direction [°], Time Historie [1]',
		titleX: 'Time [min]',
		// Y axis parameter
		yaxis: true,
		yaxisScaleMax: 360,
		yaxisScaleMin: 0,
		yaxisLabelsCount: 6,
		backgroundGridHlinesCount: 12,
		// X axis parameter
		xaxisLabelsPosition: 'edge',
		xaxisTickmarks: false,		
		backgroundGridVlines: true,
		backgroundGridVlinesCount: 21,
		xaxisLabels: ['100','90','80','70','60','50','40','30','20','10','0'],
		// Colors and lines
		colors: ['#00FF00'],
		textColor: '#808080',
		xaxisColor: '#808080',
		yaxisColor: '#808080',
		backgroundGridColor: '#808080',
		linewidth: 2,
		filled: false,
		filledColors: ['rgba(0,0,255,0.5)']
	}
}).draw();

// Initialization for line diagram wind speed
linegraph7 = new RGraph.SVG.Line({
	id: 'chart-container5',
	data: RGraph.SVG.arrayFill({
		array:  [],
		value:  0,
		length: 100
	}),
	options: {
		// Margins and border
		hmargin: 0,
		marginLeft: 50,
		marginBottom: 50,
		backgroundGridBorder: false,
		// Titles
		title: 'Wind Speed [m/s], Time Historie [1]',
		titleX: 'Time [min]',
		// Y axis parameter
		yaxis: true,
		yaxisScaleMax: 40,
		yaxisScaleMin: 0,
		yaxisLabelsCount: 4,
		backgroundGridHlinesCount: 8,
		// X axis parameter
		xaxisLabelsPosition: 'edge',
		xaxisTickmarks: false,		
		backgroundGridVlines: true,
		backgroundGridVlinesCount: 21,
		xaxisLabels: ['100','90','80','70','60','50','40','30','20','10','0'],
		// Colors and lines
		colors: ['#FF8000'],
		textColor: '#808080',
		xaxisColor: '#808080',
		yaxisColor: '#808080',
		backgroundGridColor: '#808080',
		linewidth: 2,
		filled: false,
		filledColors: ['rgba(0,0,255,0.5)']
	}
}).draw();


// Receive JSON data and parse it
var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
	var myObj = JSON.parse(this.responseText);

	// Set connection status in check box on connected
	document.getElementById("cstatus").checked = true;
	document.getElementById('quality').innerHTML = myObj.ConnectionQuality.Value;

	// Define data arrays	
	s1array = new Array(1000).fill(0);
	s2array = new Array(1000).fill(0);
    	
	// Write data in Oscilloscope diagram buffer	
	for (i = 0; i < s1array.length; i++) {
		value1 = 2 + myObj.Sensor1.Data.Value[i];
		value2 = myObj.Sensor2.Data.Value[i];
		linegraph1.originalData[0].push(value1);
		linegraph1.originalData[0].shift();
		linegraph2.originalData[0].push(value2);
		linegraph2.originalData[0].shift();
	}

	// Write puls counter data for wind direction sensor
	value3 = myObj.Sensor2.PulseCounter.Value;
	if(value3 > 4){
	  value3 = 4;
	}
	if(value3 < 0){
	  value3 = 0;
	}
	linegraph3.originalData[0].push(value3);
	linegraph3.originalData[0].shift();

	// Write time1 data
	value4 = myObj.Sensor1.Time1.Value;
	if(value4 > 1000){
	  value4 = 1000;
	}
	if(value4 < 0){
	  value4 = 0;
	}
	linegraph4.originalData[0].push(value4);
	linegraph4.originalData[0].shift();

	// Write time2 data
	value5 = myObj.Sensor2.Time2.Value;
	if(value5 > 1000){
	  value5 = 1000;
	}
	if(value5 < 0){
	  value5 = 0;
	}
	linegraph5.originalData[0].push(value5);
	linegraph5.originalData[0].shift();

	// Write wind direction data
	value6 = myObj.Direction.Value;
	if(value6 > 360){
	  value6 = 360;
	}
	if(value6 < 0){
	  value6 = 0;
	}
	linegraph6.originalData[0].push(value6);
	linegraph6.originalData[0].shift();
	windGauge.setValueLatest(value6);

	// Write wind speed data
	value7 = myObj.Speed.Value;
	if(value7 > 50){
	  value7 = 50;
	}
	if(value7 < 0){
	  value7 = 0;
	}
	linegraph7.originalData[0].push(value7);
	linegraph7.originalData[0].shift();
	windGauge.setValueAverage(value7);

	// Renew the diagram with buffer data
	RGraph.SVG.redraw();
  }
  else{
    // Set connection status in check box on disconnected
	document.getElementById("cstatus").checked = false;
  }
};

// HTTP request for JSON data
function read_json() {
//  xmlhttp.open("GET", "http://192.168.4.1/json2", true);
  url = 'http://' + server_name + '/json2';
  xmlhttp.open("GET", url, true);
  xmlhttp.send();
}

// Activate the new settings when data in input changed
function activate() {
  // Set the new server name
  server_name = document.getElementById("server").value;
  // Set the actual css style
  css = 'http://' + server_name + '/css';
  document.getElementById("css_link").setAttribute("href", css); 
  console.log(server_name);
}

// Activate the new settings when push the connect button
function connect() {
  // Set the new server name
  server_name = document.getElementById("server").value;
  console.log(server_name);
}

// Disconnect when push the disconnect button
function disconnect() {
  // Set the new server name
  server_name = '0.0.0.0';
  console.log(server_name);
  document.getElementById('quality').innerHTML = 0;
}

	
// Cyclic timer (all 1000ms) for data transmission via JSON
setInterval(function(){read_json(); }, 2000);

